-- Final Project Intro DB Lab
-- GROUP E(5):
-- 2440098110 - Habibatul Rahmatiya
-- 2440041560 - Galuh Rhaka Wiratama
-- 2440060042 - Irfan Hilmansyah
-- 2440029031 - Ivan Handryks Sitanaya


------- SALES TRANSACTION PROCESS -------

-- First
--Customers come to the showroom and look at the cars along with the specifications
-- and prices of the cars.

SELECT CarName, CarTypeName, CarPower, [CarPrice] = SalesPrice, Stock
FROM MsCar c
JOIN MsCarType ct ON c.CarTypeId = ct.CarTypeId
ORDER BY SalesPrice DESC



-- Second
-- If it matches then he will carry out the purchase process,
-- in which the staff will ask and fill in the customer's personal data such as
-- customerId, name, gender, email, phone number, and address. Meanwhile,
-- if it doesn't match, the customer will leave the showroom

INSERT INTO MsCustomer VALUES
('CU016', 'Neymar Da Santos', 'Male', 'neymar11@gmail.cu.com', '081121222344', 'Jalan Alangkah No 12A')


-- Third
-- After that, the Staff will fill in the data needed to make a sales Transaction
-- such as SalesTransactionId, StaffId, CustomerId, CarId, SalesDate, and QuantityEachCar

INSERT INTO SalesTransaction VALUES
('SL016', 'ST012', 'CU016', 'CA012', '2022-01-18', 2)

-- Fourth
-- After that, the staff will give a bill form to the customer and the customer pays

SELECT SalesTransactionId, StaffId, [StaffName] = AsMsStaff.GetStaffName,
		[StaffPhone] = AsMsStaff.GetStaffPhone, CustomerId,
		[CustomerName] = AsMsCustomer.GetCustomerName,
		[CustomerPhone] = AsMsCustomer.GetCustomerPhone,
		CarId, [CarName] = AsMsCar.GetCarName,
		[CarType] = AsMsCarType.GetCarTypeName,
		[CarPower] = AsMsCar.GetCarPower,
		SalesDate, [Quantity] = QuantityEachCar,
		[CarPrice] = AsMsCar.GetCarSalesPrice,
		[TotalPay] = AsMsCar.GetCarSalesPrice * QuantityEachCar
FROM SalesTransaction,
(
	SELECT [GetCustomerName] = CustomerName,
			[GetCustomerPhone] = CustomerPhone
	FROM MsCustomer
	WHERE CustomerId = 'CU016'
) AsMsCustomer,
(
	SELECT [GetStaffName] = StaffName, [GetStaffPhone] = StaffPhone
	FROM MsStaff
	WHERE StaffId = 'ST012'
) AsMsStaff,
(
	SELECT [GetCarName] = CarName,
			[GetCarPower] = CarPower,
			[GetCarSalesPrice] = SalesPrice
	FROM MsCar
	WHERE CarId = 'CA012'
) AsMsCar,
(
	SELECT [GetCarTypeName] = CarTypeName
	FROM MsCarType
	WHERE CarTypeId = 'CT012'
) AsMsCarType
WHERE SalesTransactionId = 'SL016'



-- Fifth
-- Then, the staff will update the stock column on the MsCar table

UPDATE MsCar
SET Stock = Stock - AsMsSalesTransaction.GetQuantity
FROM MsCar,
(
	SELECT [GetQuantity] = QuantityEachCar
	FROM SalesTransaction s
	WHERE s.SalesTransactionId = 'SL016'
) AsMsSalesTransaction
WHERE CarId = 'CA012'


--If the stock runs out, the staff will delete the car data and carry out
-- the Purchase Transaction process with the vendor.


DELETE FROM MsCar
WHERE Stock = 0




----- PURCHASE TRANSACTION PROCESS -------

-- First
-- The staff will check the number of available cars

SELECT *
FROM MsCar
ORDER BY Stock ASC

-- If the car stock is empty, the staff will order a car from the vendor,
-- otherwise the staff will not process the car order from the vendor

-- Second
-- Vendor shows a list of cars and their specifications and
-- prices to staff (using vendor company database).
-- If the staff wants to buy, the staff will enter vendor data into the database
-- such as Vendor ID, name, email, phone, and address

INSERT INTO MsVendor VALUES
('VE016', 'PT Juragan Sopan', 'juragansopan@gmail.ve.com', '081211112324', 'Bandung Api No. 06')


-- Third
-- After that, the vendor gives the bill to the staff and the staff makes the payment.
-- After that, the staff enters the required data into the purchase transaction table
-- (PurchaseTransactionId, StaffId, VendorId, CarId, PurchaseDate, QuantityEachCar).

INSERT INTO PurchaseTransaction VALUES
('PU016', 'ST012', 'VE011', 'CA016', '2022-01-18', 10)


-- Fourth
-- After that, the staff will enter the car purchase data into 
-- MsCarType(Such as CarTypeId, CarTypeName) and
-- MsCar(Such as, CarId, CarTypeId, CarName, CarPower, PurchasePrice, SalesPrice, Stock)


INSERT INTO MsCarType VALUES
('CT016', 'Sedan')

INSERT INTO MsCar VALUES
('CA016', 'CT016', 'Toyota Vios', 2000, 500000000, 750000000, 10)