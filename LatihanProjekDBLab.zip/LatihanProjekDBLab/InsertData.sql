-- Final Project Intro DB Lab
-- GROUP E(5):
-- 2440098110 - Habibatul Rahmatiya
-- 2440041560 - Galuh Rhaka Wiratama
-- 2440060042 - Irfan Hilmansyah
-- 2440029031 - Ivan Handryks Sitanaya

-- INSERT DATA

INSERT INTO MsStaff VALUES
('ST001', 'Budina', 'Male', 'budirahmat11@gmail.st.com', '081123445623', 'Jalan Kenangan No. 123 B'),
('ST002', 'Felicia Angelica', 'Female', 'feliciaangel@gmail.st.com', '085690224185', 'Jalan Mutiara Putih No. 55'),
('ST003', 'Andi Irawan Susanto', 'Male', 'andisusanto@gmail.st.com', '085630978259', 'Jalan Cempaka No. 215'),
('ST004', 'Ilham Rhakabumi', 'Male', 'ilhamrhaka67@gmail.st.com', '086646803251', 'Jalan Air Hitam No.3'),
('ST005', 'Mutiara', 'Female', 'mutiadini2@gmail.st.com', '085564007125', 'Jalan Diponegoro No.6'),
('ST006', 'Rahel Aura', 'Female', 'rahelaura990@gmail.st.com', '085922145317', 'Jalan Aur Kuning No.8 Blok B'),
('ST007', 'Muhammad Aalfharizi', 'Male', 'aalfharizi234@gmail.st.com', '086933260532', 'Jalan Pandau Permai No. 9'),
('ST008', 'Giantoni Triyoga', 'Male', 'tonigian4@gmail.st.com', '086658809121', 'Jalan Ahmad Yani No.1'),
('ST009', 'Fatma Fadila Roza', 'Female', 'fatmafadilaroza@gmail.st.com', '085532860912', 'Jalan Sukamuljo No.26'),
('ST010', 'Afif Ramadhan', 'Male', 'afiframadhan88@gmail.st.com', '085569901200', 'Jalan Arifin Ahmad No. 33'),
('ST011', 'Dian Fatimah Azzarah', 'Female', 'dianfatimahazzarah@gmail.st.com', '087790674426', 'Jalan Foker No. 25'),
('ST012', 'Farhan Aziz Hakim', 'Male', 'farhanaziz@gmail.st.com', '082213378608', 'Jalan Dahlia No. 67'),
('ST013', 'Vanessa Indriana', 'Female', 'vanessaindriana5@gmail.st.com', '085690860124', 'Jalan Arwana No. 91'),
('ST014', 'Ivan Andika Hakim', 'Male', 'ivanandika002@gmail.st.com', '085341950712', 'Jalan Kutilang No. 2'),
('ST015', 'Olivia Anastasia', 'Female', 'oliviaanastasia70@gmail.st.com', '085320069120', 'Jalan Mekarsari No. 15')



INSERT INTO MsCustomer VALUES
('CU001', 'Muhammad Ilham Pratama', 'Male', 'ilhampratama99@gmail.cu.com', '081123967863', 'Jalan Anggun No. 13 F'),
('CU002', 'Reski Seftiansyah', 'Male', 'reskiseftiansyah6@gmail.cu.com', '085680224786', 'Jalan Cendrawasih No. 981'),
('CU003', 'Ashila Devta Azalia', 'Female', 'ashiladevta3@gmail.cu.com', '085630960122', 'Jalan Bukit Barisan Blok A No. 6'),
('CU004', 'Arkaan Fadhullah', 'Male', 'arkaanfad7@gmail.cu.com', '086112643251', 'Jalan Tiung No.4'),
('CU005', 'Olivia Asyifa Ramadani', 'Female', 'oliviaasyifaar@gmail.cu.com', '084864877125', 'Jalan Todak Blok B No. 12'),
('CU006', 'Dwi Risvi Fadila', 'Female', 'dwirisvif@gmail.cu.com', '085124167317', 'Jalan Panam No.9'),
('CU007', 'Fahrizal Adha', 'Male', 'fahrizaladhaa@gmail.cu.com', '086680030532', 'Jalan Delima No. 89'),
('CU008', 'Annisa Raudhatul Jannah', 'Female', 'annisarj@gmail.cu.com', '086655887600', 'Jalan Dahlia Merah No.4'),
('CU009', 'Aditya Pratama', 'Male', 'adityapratama5@gmail.cu.com', '085522830912', 'Jalan Sukajadi No.20'),
('CU010', 'Maysheila Ulandhary', 'Female', 'maysheilaulan22@gmail.cu.com', '087867908300', 'Jalan Lobak No. 63'),
('CU011', 'Selvira Anindya', 'Female', 'selviraanindyaaa@gmail.cu.com', '088090654822', 'Jalan Taman Sari No. 75'),
('CU012', 'Anggun Fitriana', 'Female', 'anggunfitriana666@gmail.cu.com', '080913678301', 'Jalan Cemara Jingga No. 9'),
('CU013', 'Paulus Silalahi', 'Male', 'paulussilalahi65@gmail.cu.com', '085600060146', 'Jalan Alam Mayang No. 99'),
('CU014', 'Chesta Adabi', 'Male', 'chestaadabiii2@gmail.cu.com', '085366590718', 'Jalan Singgalang No. 71'),
('CU015', 'Rahma Amina', 'Female', 'rahmaamina5112@gmail.cu.com', '085327121129', 'Jalan Paus Biru No. 86')

INSERT INTO MsVendor VALUES
('VE001', 'PT Intan Madya', 'ptintanmaya@gmail.ve.com', '086548901215', 'Pattimura No. 1'),
('VE002', 'Anugrah Argon Medika', 'anugrahargonmedika@gmail.ve.com', '082163490178', 'Permata Sari No. 12'),
('VE003', 'PT Cikarang Perkasa Manufactur', 'cikarangperkasa@gmail.ve.com', '085701006922', 'Cajah Cantik No. 5'),
('VE004', 'PT Usra Tampi', 'ptusratampi1@gmail.ve.com', '083720791106', 'Parit Indah No. 3'),
('VE005', 'PT Tokyo Radiator Selamat', 'tokyoradiatorselamat@gmail.ve.com', '086655430891', 'Teratai No. 22'),
('VE006', 'PT Armada Indah Agung Glass', 'armadaindahagungglass@gmail.ve.com', '089996712116', 'Sudirman No. 45'),
('VE007', 'PT Pasindo', 'ptpasindo@gmail.ve.com', '084105877604', 'Tuanku Tambusai No. 7'),
('VE008', 'PT Indospringtbk', 'ptindospringtbk@gmail.ve.com', '084550781294', 'Harapan Raya No. 77'),
('VE009', 'PT INKA', 'ptinka@gmail.ve.com', '0859777054361', 'Soekarno Hatta No. 66'),
('VE010', 'PT Selamat Sempurna', 'ptselamatsempurna@gmail.ve.com', '085199081301', 'Sumatera No. 44'),
('VE011', 'ABC Karoseri', 'abckaroseri@gmail.ve.com', '089908451185', 'Merpati No. 8'),
('VE012', 'PT Karya Catur Manunggal', 'karyacaturmanunggal@gmail.ve.com', '0888599701262', 'Kelapa Sawit No. 61'),
('VE013', 'PT Dasa Windu Agung', 'dasawinduagung@gmail.ve.com', '089512552245', 'Muka Pasar No. 30'),
('VE014', 'PT Gajah Tunggal', 'ptgajahtunggal@gmail.ve.com', '084490123105', 'Curian No. 32'),
('VE015', 'PT Bando Indonesia', 'ptbandoindonesia@gmail.ve.com', '085012309851', 'Sisingamangaraja No. 9')



INSERT INTO MsCarType VALUES
('CT001', 'Convertible'),
('CT002', 'Coupe'),
('CT003', 'Hatchback'),
('CT004', 'MPV Type'),
('CT005', 'SUV Type'),
('CT006', 'Sedan'),
('CT007', 'Station Wagon'),
('CT008', 'Double Cabin'),
('CT009', 'Sport'),
('CT010', 'Off Road'),
('CT011', 'Convertible'),
('CT012', 'Coupe'),
('CT013','Hatchback'),
('CT014', 'MPV Type'),
('CT015', 'SUV Type')

INSERT INTO MsCar VALUES
('CA001', 'CT001', 'Porsche', 4000, 300000000, 900000000, 398),
('CA002', 'CT002', 'Toyota', 6000, 750000000, 1200000000, 200),
('CA003', 'CT003', 'Honda Jazz', 2000, 100000000, 300000000, 999),
('CA004', 'CT004', 'Daihatsu Sigra', 4500, 125000000, 450000000, 843),
('CA005', 'CT005', 'Honda HR-V', 6500, 325000000, 750000000, 724),
('CA006', 'CT006', 'BMW Seri 3', 3000, 600000000, 200000000, 601),
('CA007', 'CT007', 'Chevrolet Estante', 1000, 200000000, 80000000, 167),
('CA008', 'CT008', 'Mitsubishi New Triton', 7500, 700000000, 400000000, 528),
('CA009', 'CT009', 'Bugatti Chiron', 9000, 2000000000, 1000000000, 100),
('CA010', 'CT010', 'Jeep Wrangler', 8000, 500000000, 125000000, 366),
('CA011', 'CT011', 'Aston Martin Vantage', 4000, 300000000, 900000000, 398),
('CA012', 'CT012', 'Honda Ayla', 6000, 1200000000, 750000000, 200),
('CA013', 'CT013', 'Nissan march', 2000, 300000000, 100000000, 999),
('CA014', 'CT014', 'Nissan Livina', 4500, 450000000, 125000000, 843),
('CA015', 'CT015', 'Toyota Fortuner', 6500, 750000000, 325000000, 724)



INSERT INTO SalesTransaction VALUES
('SL001', 'ST001', 'CU001', 'CA001', '2017-01-01', 1),
('SL002', 'ST002', 'CU002', 'CA002', '2019-09-12', 1),
('SL003', 'ST003', 'CU003', 'CA003', '2019-07-24', 1),
('SL004', 'ST004', 'CU004', 'CA004', '2017-09-03', 2),
('SL005', 'ST005', 'CU005', 'CA005', '2020-11-29', 1),
('SL006', 'ST006', 'CU006', 'CA006', '2021-02-27', 2),
('SL007', 'ST007', 'CU007', 'CA007', '2018-07-27', 3),
('SL008', 'ST008', 'CU008', 'CA008', '2018-03-18', 1),
('SL009', 'ST009', 'CU009', 'CA009', '2020-01-05', 1),
('SL010', 'ST010', 'CU010', 'CA010', '2022-01-15', 2),
('SL011', 'ST011', 'CU011', 'CA011', '2018-05-05', 1),
('SL012', 'ST012', 'CU012', 'CA012', '2017-06-27', 1),
('SL013', 'ST013', 'CU013', 'CA013', '2019-10-11', 1),
('SL014', 'ST014', 'CU014', 'CA014', '2020-08-20', 1),
('SL015', 'ST015', 'CU015', 'CA015', '2021-04-04', 1)

INSERT INTO SalesTransactionDetail VALUES

('SL001', 'CA001', 1),
('SL002', 'CA002', 1),
('SL003', 'CA003', 1),
('SL004', 'CA004', 2),
('SL005', 'CA005', 1),
('SL006', 'CA006', 2),
('SL007', 'CA007', 3),
('SL008', 'CA008', 1),
('SL009', 'CA009', 1),
('SL010', 'CA010', 2),
('SL011', 'CA011', 1),
('SL012', 'CA012', 1),
('SL013', 'CA013', 1),
('SL014', 'CA014', 1),
('SL015', 'CA015', 1),
('SL012', 'CA001', 1),
('SL011', 'CA012', 1),
('SL011', 'CA012', 2),
('SL011', 'CA014', 1),
('SL012', 'CA014', 1),
('SL012', 'CA001', 1),
('SL012', 'CA002', 2),
('SL012', 'CA003', 1),
('SL013', 'CA004', 1),
('SL014', 'CA015', 1)



INSERT INTO PurchaseTransaction VALUES
('PU001', 'ST001', 'VE001', 'CA001', '2016-12-01', 1),
('PU002', 'ST002', 'VE002', 'CA002', '2019-08-12', 7),
('PU003', 'ST003', 'VE003', 'CA003', '2019-06-24', 10),
('PU004', 'ST004', 'VE004', 'CA004', '2017-08-03', 10),
('PU005', 'ST005', 'VE005', 'CA005', '2020-10-29', 8),
('PU006', 'ST006', 'VE006', 'CA006', '2021-02-28', 6),
('PU007', 'ST007', 'VE007', 'CA007', '2018-06-27', 10),
('PU008', 'ST008', 'VE008', 'CA008', '2018-02-18', 30),
('PU009', 'ST009', 'VE009', 'CA009', '2019-12-05', 8),
('PU010', 'ST010', 'VE010', 'CA010', '2021-12-15', 10),
('PU011', 'ST011', 'VE011', 'CA011', '2018-04-05', 5),
('PU012', 'ST012', 'VE012', 'CA012', '2017-05-27', 7),
('PU013', 'ST013', 'VE013', 'CA013', '2019-09-11', 9),
('PU014', 'ST014', 'VE014', 'CA014', '2020-07-20', 9),
('PU015', 'ST015', 'VE015', 'CA015', '2021-03-04', 8)



INSERT INTO PurchaseTransactionDetail VALUES
('PU001', 'CA001', 1),
('PU002', 'CA002', 7),
('PU003', 'CA003', 10),
('PU004', 'CA004', 10),
('PU005', 'CA005', 8),
('PU006', 'CA006', 6),
('PU007', 'CA007', 10),
('PU008', 'CA008', 30),
('PU009', 'CA009', 8),
('PU010', 'CA010', 10),
('PU011', 'CA011', 5),
('PU012', 'CA012', 7),
('PU013', 'CA013', 9),
('PU014', 'CA014', 9),
('PU015', 'CA015', 8),
('PU002', 'CA010', 7),
('PU003', 'CA001', 9),
('PU015', 'CA002', 9),
('PU014', 'CA003', 10),
('PU013', 'CA004', 10),
('PU009', 'CA005', 5),
('PU010', 'CA007', 5),
('PU004', 'CA001', 7),
('PU006', 'CA005', 6),
('PU012', 'CA013', 5)