-- Final Project Intro DB Lab
-- GROUP E(5):
-- 2440098110 - Habibatul Rahmatiya
-- 2440041560 - Galuh Rhaka Wiratama
-- 2440060042 - Irfan Hilmansyah
-- 2440029031 - Ivan Handryks Sitanaya


-- CREATE DATABASE DAN TABLE

CREATE DATABASE BluejackWheelz
USE BlueJackWheelz

CREATE TABLE MsStaff(
	StaffId CHAR(5) PRIMARY KEY CHECK(StaffId LIKE 'ST[0-9][0-9][0-9]') NOT NULL,
	StaffName VARCHAR(100) CHECK(LEN(StaffName) > 2) NOT NULL,
	StaffGender VARCHAR(100) CHECK(StaffGender = 'Male' OR StaffGender = 'Female') NOT NULL,
	StaffEmail VARCHAR(100) CHECK(StaffEmail LIKE '%.st.com') NOT NULL,
	StaffPhone VARCHAR(100) CHECK(StaffPhone LIKE '08%') NOT NULL,
	StaffAddress VARCHAR(100) NOT NULL
)

CREATE TABLE MsCustomer(
	
	CustomerId CHAR(5) PRIMARY KEY CHECK(CustomerId LIKE 'CU[0-9][0-9][0-9]') NOT NULL,
	CustomerName VARCHAR(100) CHECK(LEN(CustomerName) > 2) NOT NULL,
	CustomerGender VARCHAR(100) CHECK(CustomerGender = 'Male' OR CustomerGender = 'Female') NOT NULL,
	CustomerEmail VARCHAR(100) CHECK(CustomerEmail LIKE '%.cu.com') NOT NULL,
	CustomerPhone VARCHAR(100) CHECK(CustomerPhone LIKE '08%') NOT NULL,
	CustomerAddress VARCHAR(100) NOT NULL
)

CREATE TABLE MsVendor(
VendorId CHAR(5) PRIMARY KEY CHECK(VendorId LIKE 'VE[0-9][0-9][0-9]') NOT NULL,
VendorName VARCHAR(100) CHECK(LEN(VendorName) > 3) NOT NULL,
VendorEmail VARCHAR(100) CHECK(VendorEmail LIKE '%.ve.com') NOT NULL,
VendorPhone VARCHAR(100) CHECK(VendorPhone LIKE '08%') NOT NULL,
VendorAddress VARCHAR(100) NOT NULL
)

CREATE TABLE MsCarType(
	CarTypeId CHAR(5) PRIMARY KEY CHECK(CarTypeId LIKE 'CT[0-9][0-9][0-9]') NOT NULL,
	CarTypeName VARCHAR(100) CHECK(CarTypeName = 'Convertible' OR CarTypeName = 'Coupe' OR
					CarTypeName = 'Hatchback' OR CarTypeName = 'MPV Type' OR CarTypeName = 'SUV Type' OR
					CarTypeName = 'Sedan' OR CarTypeName = 'Station Wagon' OR CarTypeName = 'Double Cabin' OR
					CarTypeName = 'Sport' OR CarTypeName = 'Off Road') NOT NULL
)

CREATE TABLE MsCar(
	CarId CHAR(5) PRIMARY KEY CHECK(CarId LIKE 'CA[0-9][0-9][0-9]') NOT NULL,
	
	CarTypeId CHAR(5) FOREIGN KEY REFERENCES MsCarType(CarTypeId)
					ON UPDATE CASCADE 
					ON DELETE CASCADE
					NOT NULL,
	CarName VARCHAR(100) CHECK(LEN(CarName) > 3) NOT NULL,
	CarPower FLOAT CHECK(CarPower BETWEEN 100 AND 10000) NOT NULL,
	PurchasePrice FLOAT NOT NULL,
	SalesPrice FLOAT NOT NULL,
	Stock INT NOT NULL
)

CREATE TABLE SalesTransaction (
	SalesTransactionId CHAR(5) PRIMARY KEY CHECK(SalesTransactionId LIKE 'SL[0-9][0-9][0-9]') NOT NULL,
	StaffId CHAR(5) FOREIGN KEY REFERENCES MsStaff(StaffId)
					ON UPDATE CASCADE 
					ON DELETE CASCADE
					NOT NULL,
	CustomerId CHAR(5) FOREIGN KEY REFERENCES MsCustomer(CustomerId)
					ON UPDATE CASCADE 
					ON DELETE CASCADE
					NOT NULL,
	CarId CHAR(5) CHECK(CarId LIKE 'CA[0-9][0-9][0-9]') NOT NULL,
	SalesDate DATE NOT NULL,
	QuantityEachCar INT NOT NULL
)


CREATE TABLE PurchaseTransaction(
	PurchaseTransactionId CHAR(5) PRIMARY KEY CHECK(PurchaseTransactionId LIKE 'PU[0-9][0-9][0-9]') NOT NULL,
	StaffId CHAR(5) FOREIGN KEY REFERENCES MsStaff(StaffId)
					ON UPDATE CASCADE 
					ON DELETE CASCADE
					NOT NULL,
	VendorId CHAR(5) FOREIGN KEY REFERENCES MsVendor(VendorId)
					ON UPDATE CASCADE 
					ON DELETE CASCADE
					NOT NULL,
	CarId CHAR(5) CHECK(CarId LIKE 'CA[0-9][0-9][0-9]') NOT NULL,
	PurchaseDate DATE NOT NULL,
	QuantityEachCar INT NOT NULL
)


CREATE TABLE SalesTransactionDetail(
	
	SalesTransactionId CHAR(5) FOREIGN KEY REFERENCES SalesTransaction(SalesTransactionId) 
					ON UPDATE CASCADE 
					ON DELETE CASCADE
					NOT NULL,
	CarId CHAR(5) FOREIGN KEY REFERENCES MsCar(CarId)
					ON UPDATE CASCADE 
					ON DELETE CASCADE
					NOT NULL,
	QuantityEachCar INT NOT NULL,


)


CREATE TABLE PurchaseTransactionDetail(
	PurchaseTransactionId CHAR(5) FOREIGN KEY REFERENCES PurchaseTransaction(PurchaseTransactionId) 
					ON UPDATE CASCADE 
					ON DELETE CASCADE
					NOT NULL,
		CarId CHAR(5) FOREIGN KEY REFERENCES MsCar(CarId)
					ON UPDATE CASCADE 
					ON DELETE CASCADE
					NOT NULL,
	
	QuantityEachCar INT NOT NULL,

	CONSTRAINT CompositeKey2 PRIMARY KEY(CarId, PurchaseTransactionId)
)