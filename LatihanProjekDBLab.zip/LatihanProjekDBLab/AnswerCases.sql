-- Final Project Intro DB Lab
-- GROUP E(5):
-- 2440098110 - Habibatul Rahmatiya
-- 2440041560 - Galuh Rhaka Wiratama
-- 2440060042 - Irfan Hilmansyah
-- 2440029031 - Ivan Handryks Sitanaya

-- Query 10 Cases

-- NOMOR 1

SELECT CustomerName, StaffName, [Total Transaction] = COUNT(std.SalesTransactionId)
FROM SalesTransaction st
JOIN MsCustomer c ON st.CustomerId = c.CustomerId
JOIN MsStaff s ON st.StaffId = s.StaffId
JOIN SalesTransactionDetail std ON st.SalesTransactionId = std.SalesTransactionId
WHERE DATENAME(MONTH, SalesDate) = 'April'
AND CustomerName LIKE '% %'
GROUP BY CustomerName, StaffName


-- NOMOR 2

SELECT CarTypeName,
		[Total Price] = ' $' + CAST((CAST(PurchasePrice AS numeric) * QuantityEachCar) AS varchar)
FROM MsCarType ct
JOIN MsCar c ON ct.CarTypeId = c.CarTypeId
JOIN PurchaseTransactionDetail ptd ON ptd.CarId = c.CarId
WHERE CarTypeName LIKE '%o%'
AND (PurchasePrice * QuantityEachCar) > 12000


-- NOMOR 3

SELECT [Date] = CONVERT(varchar, PurchaseDate, 106), VendorName,
		[Total Car] = COUNT(ptd.CarId),
		[Total Quantity] = SUM(ptd.QuantityEachCar)
FROM MsVendor v
JOIN PurchaseTransaction pt ON v.VendorId = pt.VendorId
JOIN PurchaseTransactionDetail ptd ON pt.PurchaseTransactionId = ptd.PurchaseTransactionId
WHERE LEN(VendorName) > 4
AND DATENAME(MONTH, PurchaseDate) = 'March'
GROUP BY PurchaseDate, VendorName


-- Nomor 4

SELECT StaffName, CarName,
		[Total Car] = COUNT(std.CarId),
		[Total Price] = '$ ' + CAST((CAST(SalesPrice AS numeric) * std.QuantityEachCar) AS varchar)
FROM MsStaff s
JOIN SalesTransaction st ON s.StaffId = st.StaffId
JOIN SalesTransactionDetail std ON st.SalesTransactionId = std.SalesTransactionId
JOIN MsCar c ON c.CarId = std.CarId
WHERE StaffGender = 'Female'
GROUP BY StaffName, CarName, SalesPrice, std.QuantityEachCar
HAVING COUNT(std.CarId) > 1
ORDER BY (SalesPrice * std.QuantityEachCar) DESC


-- NOMOR 5

SELECT DISTINCT VendorName, VendorEmail, VendorAddress, CarName,
		[CarPower] = CAST(CarPower AS varchar) + ' Horse Power'
FROM MsVendor v
JOIN PurchaseTransaction pt ON v.VendorId = pt.VendorId
JOIN PurchaseTransactionDetail ptd ON pt.PurchaseTransactionId = ptd.PurchaseTransactionId
JOIN MsCar c ON ptd.CarId = c.CarId,
(
		SELECT [CheapestPrice] =  MIN(PurchasePrice)
		FROM MsCar
) AsCPrice
WHERE c.PurchasePrice = AsCPrice.CheapestPrice
AND VendorAddress LIKE 'C%'
ORDER BY VendorName ASC


-- NOMOR 6

SELECT DISTINCT CustomerName, CustomerEmail, CustomerPhone
				, CarName, [Car Price] = '$' + CAST(CAST(SalesPrice AS numeric) AS varchar)
FROM MsCustomer c
JOIN SalesTransaction st ON c.CustomerId = st.CustomerId
JOIN  SalesTransactionDetail std ON st.SalesTransactionId = std.SalesTransactionId
JOIN MsCar ca ON std.CarId = ca.CarId,
(
		 SELECT [CheapestCar] = MIN(SalesPrice)
		 FROM MsCar
) AsCCar
WHERE SalesPrice = AsCCar.CheapestCar
AND CarName LIKE '%n%'
ORDER BY CustomerName ASC


-- NOMOR 7

SELECT StaffName, [Date] = CONVERT(varchar, SalesDate, 106),
		CarName, [Total Price] = '$ ' + CAST((CAST(SalesPrice AS numeric) * std.QuantityEachCar) AS varchar)
FROM MsStaff s
JOIN SalesTransaction st ON s.StaffId = st.StaffId
JOIN SalesTransactionDetail std ON st.SalesTransactionId = std.SalesTransactionId
JOIN MsCar c ON  std.CarId = c.CarId,
(
		SELECT [AvgLengthName] = AVG(LEN(StaffName))
		FROM MsStaff
) AsAvgName
WHERE LEN(StaffName) > AsAvgName.AvgLengthName
AND DAY(SalesDate) % 2 = 0


-- NOMOR 8


SELECT [Vendor Name] = UPPER(VendorName),[PurchaseID] = ptd.PurchaseTransactionId,
		[Total Price] = ' $' + CAST((CAST(PurchasePrice AS numeric) * ptd.QuantityEachCar) AS varchar)
FROM MsVendor v
JOIN PurchaseTransaction pt ON v.VendorId = pt.VendorId
JOIN PurchaseTransactionDetail ptd ON pt.PurchaseTransactionId = ptd.PurchaseTransactionId
JOIN MsCar c ON ptd.CarId = c.CarId,
(
		SELECT [Average] = AVG(PurchasePrice)
		FROM MsCar
) AsACarPrice
WHERE (PurchasePrice * ptd.QuantityEachCar) < AsACarPrice.Average
AND VendorName LIKE '%a%'
ORDER BY (PurchasePrice * ptd.QuantityEachCar) DESC


-- NOMOR 9

CREATE VIEW viewStaffPurchase 
AS
SELECT StaffName, StaffEmail, [Total Car Purchase] = COUNT(ptd.PurchaseTransactionId),
		[Average Quantity] = AVG(ptd.QuantityEachCar)
FROM MsStaff s
JOIN PurchaseTransaction pt ON s.StaffId = pt.StaffId
JOIN PurchaseTransactionDetail ptd ON pt.PurchaseTransactionId = ptd.PurchaseTransactionId
WHERE StaffName NOT LIKE '% %'
AND LEN(StaffName) > 5
GROUP BY StaffName, StaffEmail




-- NOMOR 10

CREATE VIEW viewCustomerFemalePurchase
AS
SELECT CustomerName, [Customer Email] = REPLACE(CustomerEmail, '.cu', 'customer'),
		CustomerAddress, [Total Car Purchase] = COUNT(std.SalesTransactionId),
		[Average Quantity] = AVG(std.QuantityEachCar)
FROM MsCustomer c
JOIN SalesTransaction st ON C.CustomerId = st.CustomerId
JOIN SalesTransactionDetail std ON st.SalesTransactionId = std.SalesTransactionId
WHERE CustomerGender = 'Female'
GROUP BY CustomerName, CustomerEmail, CustomerAddress
HAVING COUNT(std.SalesTransactionId) > 1